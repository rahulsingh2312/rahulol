import threading
import time

# Constants
N = 10
THINKING = 2
HUNGRY = 1
EATING = 0
times = 200

phil = [i for i in range(N)]

class Monitor:
    def _init_(self):
        self.state = [THINKING] * N
        self.phcond = [threading.Condition() for _ in range(N)]

    def test(self, phnum):
        with self.phcond[phnum]:
            if (self.state[(phnum + 1) % N] != EATING and
                self.state[(phnum + N - 1) % N] != EATING and
                self.state[phnum] == HUNGRY):
                self.state[phnum] = EATING
                self.phcond[phnum].notify()

    def take_fork(self, phnum):
        with self.phcond[phnum]:
            self.state[phnum] = HUNGRY
            self.test(phnum)
            if self.state[phnum] != EATING:
                self.phcond[phnum].wait()
                print(f"Philosopher {phnum} is EATING")

    def put_fork(self, phnum):
        with self.phcond[phnum]:
            self.state[phnum] = THINKING
            self.test((phnum + 1) % N)
            self.test((phnum + N - 1) % N)

# Global object of the monitor
phil_object = Monitor()

def philosopher(phnum):
    c = 0
    while c < times:
        time.sleep(1)
        phil_object.take_fork(phnum)
        time.sleep(0.5)
        phil_object.put_fork(phnum)
        c += 1

def main():
    threads = []
    for i in range(N):
        t = threading.Thread(target=philosopher, args=(phil[i],))
        threads.append(t)
        t.start()
        print(f"Philosopher {i + 1} is thinking...")

    for i in range(N):
        threads[i].join()

if _name_ == "_main_":
    main()