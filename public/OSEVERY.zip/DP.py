import threading
import time
import random

num_philosophers = 5
num_meals = 3

forks = [threading.Semaphore(1) for _ in range(num_philosophers)]
mutex = threading.Semaphore(1)

def philosopher(index, meals_to_eat):
    for _ in range(meals_to_eat):
        print(f"Philosopher {index} is thinking...")
        time.sleep(random.randint(1, 5))
        left, right = index, (index + 1) % num_philosophers
        with mutex:
            forks[left].acquire()
            forks[right].acquire()
        print(f"Philosopher {index} is eating...")
        time.sleep(random.randint(1, 5))
        forks[left].release()
        forks[right].release()

threads = [threading.Thread(target=philosopher, args=(i, num_meals)) for i in range(num_philosophers)]
[thread.start() for thread in threads]
[thread.join() for thread in threads]

print("All philosophers have finished their meals.")
