def calculateNeed(need, maxm, allot):
    for i in range(P):
        for j in range(R):
            need[i][j] = maxm[i][j] - allot[i][j]

def isSafe(processes, avail, maxm, allot):
    need = [[maxm[i][j] - allot[i][j] for j in range(R)] for i in range(P)]
    finish = [0] * P
    safeSeq = []
    work = avail[:]

    while len(safeSeq) < P:
        found = False
        for p in range(P):
            if finish[p] == 0 and all(need[p][j] <= work[j] for j in range(R)):
                for k in range(R):
                    work[k] += allot[p][k]
                safeSeq.append(p)
                finish[p] = 1
                found = True
                break
        if not found:
            print("System is not in safe state")
            return False

    print("System is in safe state.", "\nSafe sequence is:", *safeSeq)
    return True

if __name__ == "__main__":
    P, R = 5, 3
    avail = [3, 3, 2]
    maxm = [[7, 5, 3], [3, 2, 2], [9, 0, 2], [2, 2, 2], [4, 3, 3]]
    allot = [[0, 1, 0], [2, 0, 0], [3, 0, 2], [2, 1, 1], [0, 0, 2]]
    isSafe(range(P), avail, maxm, allot)
