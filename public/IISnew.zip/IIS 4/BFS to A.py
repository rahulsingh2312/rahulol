import heapq

def a_star_search(graph, start, goal, heuristic):
    open_list = [(0, start)]  # Initialize with (f(n), node)
    closed_set = set()
    parent = {}
    g_costs = {start: 0}  # Store g(n) costs

    while open_list:
        # Get the node with the lowest f(n) = g(n) + h(n)
        current_node = heapq.heappop(open_list)[1]

        # Check if the current node is the goal
        if current_node == goal:
            return reconstruct_path(parent, start, goal)

        closed_set.add(current_node)

        # Explore neighbors
        for neighbor in graph[current_node]:
            # Calculate g(n) cost for the neighbor
            tentative_g_cost = g_costs[current_node] + 1  # Assuming a cost of 1 to move to a neighbor

            # If this path to neighbor is better, update the costs and parent
            if neighbor not in g_costs or tentative_g_cost < g_costs[neighbor]:
                g_costs[neighbor] = tentative_g_cost
                f_cost = tentative_g_cost + heuristic(neighbor)
                parent[neighbor] = current_node

                # Check if the neighbor is already in the open list
                if not any(n[1] == neighbor for n in open_list):
                    heapq.heappush(open_list, (f_cost, neighbor))

    return None  # Return None if no path is found

def reconstruct_path(parent, start, goal):
    path = []
    current_node = goal

    while current_node != start:
        path.append(current_node)
        current_node = parent[current_node]
    
    path.append(start)  # Add the start node at the end
    path.reverse()      # Reverse the path to get the correct order
    return path

# Define the graph as an adjacency list
graph = {
    'A': ['B', 'C'],
    'B': ['D'],
    'C': ['E'],
    'D': ['F'],
    'E': ['F'],
    'F': []
}

start_node = 'A'
goal_node = 'F'

# Heuristic function
def heuristic(node):
    # Simple heuristic: distance to the goal based on ASCII values
    if node == 'F':
        return 0
    return abs(ord(node) - ord('F'))

# Perform A* Search
solution = a_star_search(graph, start_node, goal_node, heuristic)
if solution:
    print("Solution found:", solution)
else:
    print("No solution found.")
