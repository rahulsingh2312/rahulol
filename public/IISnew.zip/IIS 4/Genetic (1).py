import random

def fitness(individual):
    return sum(individual)  # The weight is the sum of the array elements

def create_individual(array_size, lower_bound, upper_bound):
    return [random.randint(lower_bound, upper_bound) for _ in range(array_size)]

def create_population(pop_size, array_size, lower_bound, upper_bound):
    return [create_individual(array_size, lower_bound, upper_bound) for _ in range(pop_size)]

def select_parents(population, fitness_values):
    total_fitness = sum(fitness_values)
    probabilities = [f / total_fitness for f in fitness_values]
    parents = random.choices(population, weights=probabilities, k=2)
    return parents

def crossover(parent1, parent2):
    crossover_point = random.randint(1, len(parent1) - 1)  # Random crossover point
    child1 = parent1[:crossover_point] + parent2[crossover_point:]
    child2 = parent2[:crossover_point] + parent1[crossover_point:]
    return child1, child2

def mutate(individual, mutation_rate, lower_bound, upper_bound):
    for i in range(len(individual)):
        if random.random() < mutation_rate:
            individual[i] = random.randint(lower_bound, upper_bound)
    return individual

def genetic_algorithm(generations, population_size, array_size, lower_bound, upper_bound, mutation_rate):
    population = create_population(population_size, array_size, lower_bound, upper_bound)
    
    for generation in range(generations):
        fitness_values = [fitness(ind) for ind in population]
        
        best_individual = population[fitness_values.index(max(fitness_values))]
        print(f"Generation {generation + 1}: Best = {best_individual}, Fitness = {max(fitness_values)}")
        
        new_population = []
        for _ in range(population_size // 2):
            parent1, parent2 = select_parents(population, fitness_values)
            child1, child2 = crossover(parent1, parent2)
            child1 = mutate(child1, mutation_rate, lower_bound, upper_bound)
            child2 = mutate(child2, mutation_rate, lower_bound, upper_bound)
            new_population.extend([child1, child2])
        
        population = new_population

    fitness_values = [fitness(ind) for ind in population]
    return population[fitness_values.index(max(fitness_values))]

# Parameters
generations = 10
population_size = 6
array_size = 5
lower_bound = 0
upper_bound = 10
mutation_rate = 0.1

# Run the Genetic Algorithm
best_solution = genetic_algorithm(generations, population_size, array_size, lower_bound, upper_bound, mutation_rate)
print(f"Best solution: {best_solution}, Fitness (weight): {fitness(best_solution)}")
