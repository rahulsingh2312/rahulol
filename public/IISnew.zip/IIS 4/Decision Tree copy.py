dataset = [
    [2.5, 1.5, 0],
    [1.5, 2.0, 0],
    [3.0, 2.5, 0],
    [7.0, 3.0, 1],
    [8.0, 2.5, 1],
    [9.0, 3.5, 1]
]

# Function to split the dataset based on a feature and value
def split_data(dataset, feature_index, value):
    left_split = []
    right_split = []
    for row in dataset:
        if row[feature_index] <= value:
            left_split.append(row)
        else:
            right_split.append(row)
    return left_split, right_split

# Function to calculate Gini Impurity
def gini(groups):
    total_samples = sum([len(group) for group in groups])
    gini_score = 0.0
    for group in groups:
        size = len(group)
        if size == 0:  # Avoid division by zero
            continue
        score = 0.0
        # Calculate the score for each class in the group
        class_values = [row[-1] for row in group]
        for class_value in [0, 1]:
            proportion = class_values.count(class_value) / size
            score += proportion * proportion
        # Weighted Gini for the group
        gini_score += (1 - score) * (size / total_samples)
    return gini_score

# Function to find the best split
def find_best_split(dataset):
    best_gini = float("inf")
    best_feature_index = None
    best_value = None
    best_splits = None
    
    for feature_index in range(len(dataset[0]) - 1):  # For each feature
        for row in dataset:
            value = row[feature_index]
            groups = split_data(dataset, feature_index, value)
            gini_score = gini(groups)
            if gini_score < best_gini:
                best_gini = gini_score
                best_feature_index = feature_index
                best_value = value
                best_splits = groups
                
    return best_feature_index, best_value, best_splits

# Build a simple decision tree with one split
def build_tree(dataset):
    feature_index, value, (left, right) = find_best_split(dataset)
    return {'feature_index': feature_index, 'value': value, 'left': left, 'right': right}

# Predict using the decision tree
def predict(tree, row):
    if row[tree['feature_index']] <= tree['value']:
        return tree['left'][0][-1]  # Predict the class of the first sample in the left group
    else:
        return tree['right'][0][-1]  # Predict the class of the first sample in the right group

# Build and test the decision tree
tree = build_tree(dataset)

# Test sample
new_sample = [2.0, 2.5]
prediction = predict(tree, new_sample)
print(f"Prediction for {new_sample}: {prediction}")
