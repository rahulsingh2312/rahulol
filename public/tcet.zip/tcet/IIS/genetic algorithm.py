import random

def genetic_algorithm(population, fitness_function, mutation_rate, crossover_rate, num_generations):
    for generation in range(num_generations):
        # Selection
        selected_population = selection(population, fitness_function)

        # Crossover
        offspring = crossover(selected_population, crossover_rate)

        # Mutation
        mutated_offspring = mutation(offspring, mutation_rate)

        # Replace old population with offspring
        population = selected_population + mutated_offspring

        # Find the best individual in the current generation
        best_individual = max(population, key=fitness_function)

        print(f"Generation {generation + 1}: Best fitness = {fitness_function(best_individual)}")

    return best_individual

def selection(population, fitness_function):
    selected_population = []
    for _ in range(len(population)):
        tournament = random.sample(population, 2)
        selected_population.append(max(tournament, key=fitness_function))

    return selected_population

def crossover(population, crossover_rate):
    offspring = []
    for i in range(0, len(population), 2):
        parent1 = population[i]
        parent2 = population[i + 1]

        if random.random() < crossover_rate:
            child1, child2 = crossover_operation(parent1, parent2)
            offspring.extend([child1, child2])
        else:
            offspring.extend([parent1, parent2])

    return offspring

def crossover_operation(parent1, parent2):
    crossover_point = random.randint(1, len(parent1) - 1)
    child1 = parent1[:crossover_point] + parent2[crossover_point:]
    child2 = parent2[:crossover_point] + parent1[crossover_point:]

    return child1, child2

def mutation(population, mutation_rate):
    mutated_population = []
    for individual in population:
        if random.random() < mutation_rate:
            mutated_individual = mutate_individual(individual)
            mutated_population.append(mutated_individual)
        else:
            mutated_population.append(individual)

    return mutated_population

def mutate_individual(individual):
    return individual

def generate_initial_population(population_size):
    population = []
    for _ in range(population_size):
        individual = [random.randint(0, 1) for _ in range(individual_length)] 
        population.append(individual)

    return population

def fitness_function(individual):
    return sum(individual)

# Example usage
population_size = 100
num_generations = 100
mutation_rate = 0.01
crossover_rate = 0.7
individual_length = 10

population = generate_initial_population(population_size)
best_individual = genetic_algorithm(population, fitness_function, mutation_rate, crossover_rate, num_generations)