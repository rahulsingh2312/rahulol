def hill_climbing(initial_state, objective_function, generate_neighbors):
    current_state = initial_state
    best_value = objective_function(current_state)

    while True:
        neighbors = generate_neighbors(current_state)
        best_neighbor = None
        best_neighbor_value = None

        for neighbor in neighbors:
            neighbor_value = objective_function(neighbor)
            if neighbor_value > best_value:
                best_neighbor = neighbor
                best_neighbor_value = neighbor_value

        if best_neighbor is None or best_neighbor_value <= best_value:
            return current_state

        current_state = best_neighbor
        best_value = best_neighbor_value
        
def objective_function(state):
    # Example objective function: Maximize the sum of elements
    return sum(state)

def generate_neighbors(state):
    # Example neighbor generation: Swap two elements randomly
    neighbors = []
    for i in range(len(state)):
        for j in range(i + 1, len(state)):
            neighbor = state.copy()
            neighbor[i], neighbor[j] = neighbor[j], neighbor[i]
            neighbors.append(neighbor)
    return neighbors

initial_state = [1, 2, 3, 4, 5]

solution = hill_climbing(initial_state, objective_function, generate_neighbors)
print("Solution:", solution)