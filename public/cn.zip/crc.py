def crc32_checksum(data):

    crc = 0xFFFFFFFF 
    polynomial = 0xEDB88320 

    for byte in data:
        crc ^= byte
        for _ in range(8):
            if crc & 1:
                crc = (crc >> 1) ^ polynomial
            else:
                crc >>= 1
    return crc ^ 0xFFFFFFFF
def check_crc(data, checksum):
    
    return crc32_checksum(data) == checksum


data = b"Hello, world!"
checksum = crc32_checksum(data)
print("CRC-32 checksum:", checksum)


received_data = b"Hello, world!" 
received_checksum = crc32_checksum(received_data)


if check_crc(received_data, received_checksum):
    print("No error detected.")
else:
    print("Error detected.")
