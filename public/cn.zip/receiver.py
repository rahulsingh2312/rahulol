import socket  # Import the socket module

UDP_IP = "127.0.0.1"  # Define the IP address to bind the socket to
UDP_PORT = 5005  # Define the port number to bind the socket to

# Create a UDP socket
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# Bind the socket to the specified IP address and port
sock.bind((UDP_IP, UDP_PORT))

# Start an infinite loop to continuously receive messages
while True:
    # Receive data from the socket (maximum 1024 bytes)
    data, addr = sock.recvfrom(1024)
    # Decode the received bytes to string and print the received message
    print("Received message:", data.decode())
    # Break the loop after receiving one message
    break
