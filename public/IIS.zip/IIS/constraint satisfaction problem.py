from itertools import permutations

def check_cryptarithm(equation):
    parts = equation.split("=")
    left_side = parts[0].strip().split("+")
    right_side = parts[1].strip()

    if len(left_side) != 2 or not right_side:
        print("Invalid equation format. Please use 'WORD + WORD = RESULT'.")
        return

    # Collect unique letters
    unique_letters = set("".join(left_side) + right_side)
    if len(unique_letters) > 10:
        print("Too many unique letters. Maximum is 10.")
        return

    # Assign letters to digits
    for perm in permutations(range(10), len(unique_letters)):
        letter_to_digit = dict(zip(unique_letters, perm))
        
        # Calculate the numerical values
        left_value = sum(letter_to_digit[letter] * (10 ** (len(word) - 1 - i)) 
                         for word in left_side for i, letter in enumerate(word))
        right_value = sum(letter_to_digit[letter] * (10 ** (len(right_side) - 1 - i)) 
                          for i, letter in enumerate(right_side))
        
        if left_value == right_value:
            print(f"Solution found: {letter_to_digit}")
            return
    
    print("No solution found.")

# User interface
user_input = input("Enter your equation (e.g., 'TWO + TWO = FOUR'): ")
check_cryptarithm(user_input)
