import heapq

def best_first_search(graph, start, goal, heuristic):

    open_list = [(heuristic(start), start)]
    closed_set = set()
    parent = {}

    while open_list:
        current_node = open_list.pop(0)[1]

        if current_node == goal:
            return reconstruct_path(parent, start, goal)

        closed_set.add(current_node)

        for neighbor in graph[current_node]:
            if neighbor not in closed_set:
                new_cost = heuristic(neighbor)
                if (new_cost, neighbor) not in open_list:
                    parent[neighbor] = current_node
                    heapq.heappush(open_list, (new_cost, neighbor))

    return None

def reconstruct_path(parent, start, goal):

    path = [goal]
    current_node = goal

    while current_node != start:
        current_node = parent[current_node]
        path.append(current_node)

    path.reverse()
    return path

graph = {
    'A': {'B': 1, 'C': 3},
    'B': {'D': 2},
    'C': {'E': 1},
    'D': {'F': 2},
    'E': {'F': 1},
    'F': {}
}

start_node = 'A'
goal_node = 'F'

def heuristic(node):
    if node == 'F':
        return 0
    return abs(ord(node) - ord('F'))

solution = best_first_search(graph, start_node, goal_node, heuristic)
if solution:
    print("Solution found:", solution)
else:
    print("No solution found.")