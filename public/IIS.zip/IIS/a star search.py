import heapq

def a_star_search(graph, start, goal, heuristic):
    open_list = [(0, heuristic(start), start)]  # (g_cost, f_cost, node)
    closed_set = set()
    parent = {}
    g_costs = {start: 0}  # Store the g_cost for each node

    while open_list:
        current_node = heapq.heappop(open_list)[2]

        if current_node == goal:
            return reconstruct_path(parent, start, goal), g_costs[goal]

        closed_set.add(current_node)

        for neighbor, cost in graph[current_node].items():
            if neighbor not in closed_set:
                new_g_cost = g_costs[current_node] + cost
                new_f_cost = new_g_cost + heuristic(neighbor)

                if neighbor not in g_costs or new_g_cost < g_costs[neighbor]:
                    g_costs[neighbor] = new_g_cost
                    parent[neighbor] = current_node
                    heapq.heappush(open_list, (new_f_cost, new_g_cost, neighbor))

    return None, None

def reconstruct_path(parent, start, goal):
    path = [goal]
    current_node = goal

    while current_node != start:
        current_node = parent[current_node]
        path.append(current_node)

    path.reverse()
    return path

graph = {
    'A': {'B': 1, 'C': 3},
    'B': {'D': 2},
    'C': {'E': 1},
    'D': {'F': 2},
    'E': {'F': 1},
    'F': {}
}

start_node = 'A'
goal_node = 'F'

def heuristic(node):
    # Example heuristic: Manhattan distance
    if node == 'F':
        return 0
    return abs(ord(node) - ord('F'))

solution, cost = a_star_search(graph, start_node, goal_node, heuristic)
if solution:
    print("Solution found:", solution)
    print("Total cost:", cost)
else:
    print("No solution found.")