def iterative_deepening_search(graph, start, goal):

    for depth_limit in range(1, len(graph)):
        path = depth_limited_search(graph, start, goal, depth_limit)
        if path:
            return path

    return None

def depth_limited_search(graph, start, goal, depth_limit):

    if start == goal:
        return [start]

    if depth_limit == 0:
        return None

    for neighbor in graph[start]:
        path = depth_limited_search(graph, neighbor, goal, depth_limit - 1)
        if path:
            return [start] + path

    return None
graph = {
    'A': ['B', 'C'],
    'B': ['D', 'E'],
    'C': ['F'],
    'D': [],
    'E': [],
    'F': []
}

start_node = 'A'
goal_node = 'F'

solution = iterative_deepening_search(graph, start_node, goal_node)
if solution:
    print("Solution found:", solution)
else:
    print("No solution found.")