def depth_limited_search(graph, start, goal, depth_limit):
    if start == goal:
        return [start]

    if depth_limit == 0:
        return None

    for neighbor in graph[start]:
        path = depth_limited_search(graph, neighbor, goal, depth_limit - 1)
        if path:
            return [start] + path

    return None

graph = {
    'A': ['B', 'C'],
    'B': ['D', 'E'],
    'C': ['F'],
    'D': [],
    'E': [],
    'F': []
}

start_node = 'A'
goal_node = 'F'
depth_limit = 3  # Adjust the depth limit as needed

solution = depth_limited_search(graph, start_node, goal_node, depth_limit)
if solution:
    print("Solution found:", solution)
else:
    print("No solution found within the given depth limit.")