capacity = 4
processList = [ 7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 2,1,2,0,1,7,0,1] 
				
s = []                                     # List of current pages in Main Memory 

pageFaults = 0                             # pageHits = 0 

for i in processList: 
	                                      # If i is not present in currentPages list 
	if i not in s: 
		if(len(s) == capacity):            # Check if the list can hold equal pages 
			s.remove(s[0]) 
			s.append(i) 
		else: 
			s.append(i) 
		pageFaults +=1                    # Increment Page faults 

	# If page is already there in currentPages i.e in Main 
	else:  
		s.remove(i)                       # Remove previous index of current page
		s.append(i)                       # Now append it, at last index 
	
print("Pagefaults sre: {}".format(pageFaults)) 
hits = len(processList) - pageFaults
print(f"Number of hits are: {hits}")


