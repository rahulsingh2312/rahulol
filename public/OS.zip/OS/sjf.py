def sjf():
    n = int(input("Enter the number of processes: "))
    processes = []
   
    for i in range(1, n+1):                                                 # Input burst time for each process
        burst_time = int(input(f"Enter burst time for process {i}: "))
        processes.append((i, burst_time))

    processes.sort(key=lambda x: x[1])                                       # Sort processes by burst time

    total_waiting_time = 0
    total_turnaround_time = 0
    current_time = 0

    print("Process\tBurst Time\tWaiting Time\tTurnaround Time")
    for i in range(n):
        process_id, burst_time = processes[i]
        waiting_time = max(0, current_time)  # Calculate waiting time based on current time
        turnaround_time = waiting_time + burst_time
        total_waiting_time += waiting_time
        total_turnaround_time += turnaround_time
        current_time += burst_time
        print(f"{process_id}\t\t{burst_time}\t\t{waiting_time}\t\t{turnaround_time}")

    avg_waiting_time = total_waiting_time / n
    avg_turnaround_time = total_turnaround_time / n

    print(f"\nAverage Waiting Time: {avg_waiting_time}")
    print(f"Average Turnaround Time: {avg_turnaround_time}")

# Example usage
if __name__ == "__main__":
    sjf()
